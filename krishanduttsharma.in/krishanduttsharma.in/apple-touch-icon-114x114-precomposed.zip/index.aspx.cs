﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class blog : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        FillBlog();
    }
    public void FillBlog()
    {
        DataSet ds = new DataSet();
        ds.ReadXml(Server.MapPath("BlogDb.xml"));
        if (ds.Tables.Count > 0)
        {
            if (ds.Tables[0].Rows.Count > 0)
            {
                string str = "<section class='clearfix'><div class='g2'><ul class='no-list work'>";
                for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    str = str + "<li><h5>" + ds.Tables[0].Rows[i]["Title"].ToString();
                    str = str + "</h5><span class='label label-info'>" + ds.Tables[0].Rows[i]["Year"].ToString();
                    str = str + "</span><p>" + ds.Tables[0].Rows[i]["Details"].ToString();
                    str = str + "</p></li>";
                }
                str = str + "</ul></div>";
                str = str + "<div class='g1'><div class='main-links sidebar'><ul><li><a href='images/krishandutt.pdf' target='_blank'>Download My Resume</a></li><li><a href='#resume'>View My Resume</a></li><li><a href='#portfolio'>My Portfolio</a></li><li><a href='#contact'>Hire me for your next project</a></li><li><a href='#features'>Features</a></li><li><a href='http://www.hitwebcounter.com' target='_blank'><img src='http://hitwebcounter.com/counter/counter.php?page=6400827&style=0027&nbdigits=7&type=page&initCount=20' title='.' alt='.' border='0'></a></li><li><img src='images/kdQR.jpg' title='.' alt='.' border='0' height='200px' width='200px'></li></ul></div></div></section>";
                blog1.InnerHtml = str;
            }
        }
    }
}
