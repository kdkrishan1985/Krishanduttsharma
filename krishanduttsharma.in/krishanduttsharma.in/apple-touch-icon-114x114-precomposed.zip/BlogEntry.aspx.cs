﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml;

public partial class BlogEntry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        gridDataBind();

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Random rnd = new Random();
        int rndnumber = rnd.Next(1,99999999);

        XmlDocument XmlDocObj = new XmlDocument();
        XmlDocObj.Load(Server.MapPath("BlogDb.xml"));
        XmlNode RootNode = XmlDocObj.SelectSingleNode("BlogDb");
        XmlNode bookNode = RootNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "Blog", ""));
        bookNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "BlogID", "")).InnerText = rndnumber.ToString();
        bookNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "Title", "")).InnerText = tbTitle.Text;
        bookNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "Details", "")).InnerText = tbDetails.Text;
        bookNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "Author", "")).InnerText = tbAuthor.Text;
        bookNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "Year", "")).InnerText = System.DateTime.Now.ToString();
        XmlDocObj.Save(Server.MapPath("BlogDb.xml"));
        gridDataBind();
    }
    public void gridDataBind()
    {   DataSet ds1 = new DataSet();
        ds1.ReadXml(Server.MapPath("BlogDb.xml"));
        if (ds1.Tables.Count > 0)
        {
            if (ds1.Tables[0].Rows.Count > 0)
            {
                DataSet ds = new DataSet();
                ds.ReadXml(Server.MapPath("BlogDb.xml"));
                gvBookStoreRecords.DataSource = ds;
                gvBookStoreRecords.DataBind();
            }
        }
    }
}
