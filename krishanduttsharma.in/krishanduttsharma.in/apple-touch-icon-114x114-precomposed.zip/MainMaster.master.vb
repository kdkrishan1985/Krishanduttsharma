﻿
Partial Class MainMaster
    Inherits System.Web.UI.MasterPage
End Class

